# DAX measures

The model has two tables: `Data` (sales records) and `Measuress` (measures).

Measures used by the dashboard, all stored in `Measuress`:

| Measure | Used in | Meaning |
|---|---|---|
| `Total Houses` | No. of Houses card | Number of sales records |
| `Total Qty` | Qty Sold card, bedroom matrix | Properties sold |
| `Total Selling` | Sales Total card, bar, column, treemap, line chart | Revenue |
| `Total Cost` | Cost Total card | Property cost |
| `Total Profit` | Profit card, donut, line chart | Revenue minus cost |

## Formulas

> **Fill in before publishing.** The formulas were not readable from the file when this repo was prepared, so paste the exact DAX from your own model below. To list all of them at once:
>
> 1. In Power BI Desktop, open **DAX query view** (the DAX icon on the left).
> 2. Run:
>    ```DAX
>    EVALUATE INFO.VIEW.MEASURES()
>    ```
> 3. Copy the `Name` and `Expression` columns into this file.

```DAX
-- Total Houses =

-- Total Qty =

-- Total Selling =

-- Total Cost =

-- Total Profit =
```

## Month column
The `Month` column in `Data` drives the Month slicer and the line chart. For the months to read Jan to Dec instead of alphabetically, it must be sorted by a month-number column (**Column tools, Sort by column**).

```DAX
-- Month =

-- Month No =
```
