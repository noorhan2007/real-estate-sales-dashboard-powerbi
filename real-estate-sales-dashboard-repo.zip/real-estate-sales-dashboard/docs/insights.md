# Insights

All numbers come from the final dashboard.

## 1. Volume isn't value
- 1-bedrooms sell the most units: **1,565** (matrix total), but earn **25%** of the profit (23.48M, donut).
- 2-bedrooms sell **1,384** units and earn **42%** of the profit (40.14M).
- 3-bedrooms sell **1,320** units and earn **33%** of the profit (31.68M).

## 2. Sales depend heavily on one person
| Salesperson | Sales |
|---|---|
| Musa | 94M |
| Anita | 73M |
| Charles | 60M |
| Tulika | 25M |

Musa alone is about 37% of the 252M total.

## 3. Denver is a different business
| Location | Sales | Units sold |
|---|---|---|
| Austin | 83M | 1,378 |
| Orlando | 79M | 1,310 |
| Beverly Hills | 78M | 1,296 |
| Denver | 13M | 285 |

Denver is about 5% of sales, and 196 of its 285 units are 1-bedrooms, the lowest-profit type.

## 4. Overall
- Sales 252.17M, cost 156.87M, profit 95.29M
- Profit margin: 95.29 / 252.17 = **37.8%**
- Sales and profit move together through the year, and both peak towards the end of the year (read from the line chart)

## Possible actions
- Push 2-bedrooms, which earn the most profit per property
- Spread sales across more than one top performer
- Review the Denver strategy, starting with its property mix
