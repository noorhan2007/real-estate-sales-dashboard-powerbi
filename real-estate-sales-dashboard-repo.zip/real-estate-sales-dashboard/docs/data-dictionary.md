# Data dictionary

Table: `Data`. One row per sale record (about 3,290 rows).

| Column | Description |
|---|---|
| `SaleDate` | Date of the sale (2022 in the sample rows) |
| `Qty` | Number of properties in the sale |
| `PropertyType` | Property type, stored as bedrooms: 1 Bedroom, 2 Bedrooms, 3 Bedrooms |
| `SellingPrice` | Selling price of one property |
| `CostPrice` | Cost of one property |
| `Distance` | Distance label as stored in the source (for example "30 mns") |
| `SalesPerson` | Salesperson responsible for the sale (Musa, Anita, Charles, Tulika) |
| `Location` | Austin, Beverly Hills, Denver or Orlando |
| `Total Selling Price` | Selling price for the whole sale record |
| `Total Cost Price` | Cost for the whole sale record |
| `Total Profit` | Selling price minus cost for the whole sale record |
| `Month` | Month used by the slicer and line chart (added for the dashboard) |

Table: `Measuress`. Holds the measures only. See [../dax/measures.md](../dax/measures.md).
