# Color palette

## Base colors
| Use | HEX |
|---|---|
| Page background | `#24214A` |
| Panels / header | `#302D5A` |
| Soft panel / slicer items | `#3B3770` |
| Borders | `#45417C` |
| Text | `#FFFFFF` |
| Muted text | `#B8B5E0` |

## Gradients (start → end)
| Name | Start | End | Used for |
|---|---|---|---|
| Coral | `#D85A72` | `#E57E7F` | No. of Houses card |
| Magenta | `#B65BBA` | `#D784C9` | Qty Sold card |
| Blue | `#5E74CD` | `#699FD6` | Sales Total card |
| Violet | `#7565C7` | `#9E84D7` | Cost Total card |
| Mint | `#2FB59A` | `#6FE0C4` | Profit card |

## Header line
`#D55470` → `#B35AB8` → `#5B6AD0`
