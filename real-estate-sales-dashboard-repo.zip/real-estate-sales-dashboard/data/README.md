# Data

The data is embedded in `dashboard/real-estate-sales-dashboard.pbix`.

If you are allowed to share the source file (Excel or CSV), add it here and list its name and origin below.

- Source: _add the source or course name_
- File: _add the file name_

See [../docs/data-dictionary.md](../docs/data-dictionary.md) for the columns.
